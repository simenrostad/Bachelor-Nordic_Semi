/*  Manufacturer specific data and length defines */
#define APP_BEACON_INFO_LENGTH          0x17        
#define APP_ADV_DATA_LENGTH             0x15
#define APP_DEVICE_TYPE                 0x02 
#define APP_MEASURED_RSSI               0xC3
#define APP_COMPANY_IDENTIFIER          0x0059                
#define APP_MAJOR_VALUE                 0x01, 0x02                        
#define APP_MINOR_VALUE                 0x03, 0x04  
#define APP_BEACON_UUID                 0x01, 0x12, 0x23, 0x34, \
                                        0x45, 0x56, 0x67, 0x78, \
                                        0x89, 0x9a, 0xab, 0xbc, \
                                        0xcd, 0xde, 0xef, 0xf0
                                        
/*Information advertised by the ble_app_beacon*/
static uint8_t m_beacon_info[APP_BEACON_INFO_LENGTH] =            
{
    APP_DEVICE_TYPE
    APP_ADV_DATA_LENGTH, 
    APP_BEACON_UUID,     
    APP_MAJOR_VALUE,     
    APP_MINOR_VALUE,     
    APP_MEASURED_RSSI    
};

/*Function that initialises the data to be advertised*/
static void advertising_init(void)                                  
{
    ble_advdata_t advdata;                                          
    uint8_t       flags = BLE_GAP_ADV_FLAG_BR_EDR_NOT_SUPPORTED;

    ble_advdata_manuf_data_t manuf_specific_data;

    manuf_specific_data.company_identifier = APP_COMPANY_IDENTIFIER;
    manuf_specific_data.data.p_data = (uint8_t *) m_beacon_info;
    manuf_specific_data.data.size   = APP_BEACON_INFO_LENGTH;

    /*Build and set advertising data*/
    memset(&advdata, 0, sizeof(advdata));

    advdata.name_type             = BLE_ADVDATA_NO_NAME;
    advdata.flags                 = flags;
    advdata.p_manuf_specific_data = &manuf_specific_data;
}