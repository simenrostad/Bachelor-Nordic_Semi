/*Defines values used in advertising data*/
#define APP_BLE_CONN_CFG_TAG            1                                
#define EHSB_SERVICE_UUID_TYPE          0x02
#define BLE_UUID_EHSB_SERVICE           0x0001
#define EHSB_BASE_UUID                  0x9F, 0xCA, 0xDC, 0x24, \
                                        0x0E, 0xE5, 0xA9, 0xE0, \
                                        0x93, 0xF3, 0xA3, 0xB5, \
                                        0x00, 0x00, 0x40, 0x6E
                                        
/*Struct that takes in ehsb service uuid and ehsb service type*/
static ble_uuid_t m_adv_uuids[] =
{
    {BLE_UUID_EHSB_SERVICE, EHSB_SERVICE_UUID_TYPE}
};

/*Function that initializes the data to be advertised*/
static void advertising_init(void)   
{                                                                                      
    ble_advdata_t        advdata;
    uint8_t              flags = BLE_GAP_ADV_FLAG_BR_EDR_NOT_SUPPORTED;  
    
    /*Build and set advertising data*/
    memset(&advdata, 0, sizeof(advdata));
    
    advdata.flags                   = flags;
    advdata.uuids_complete.uuid_cnt = sizeof(m_adv_uuids)/sizeof(m_adv_uuids[0]);
    advdata.uuids_complete.p_uuids  = m_adv_uuids;
    
    /*Add UUID to softdevice*/
    ble_uuid128_t ehsb_base_uuid = EHSB_BASE_UUID;
    err_code = sd_ble_uuid_vs_add(&ehsb_base_uuid, &m_adv_uuids[0].type);
}