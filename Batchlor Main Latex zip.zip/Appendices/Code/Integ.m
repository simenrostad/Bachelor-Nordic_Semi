/*Initialising 8-bit unassigned integer array with 16 positions, set every entry to 0*/
uint8_t adv_rep_uuid[16] = {0};
/*Initialising 16-bit integer that contains the length of adv_rep_uuid*/
uint16_t adv_rep_uuid_length = sizeof(adv_rep_uuid);