/*Advertising report*/
case BLE_GAP_EVT_ADV_REPORT:
{
   ble_gap_evt_adv_report_t const * p_adv_report = &p_gap_evt->params.adv_report;
   uint8_t adv_uuid[16] = {0};
   memcpy(&adv_uuid, &p_adv_report->data[5], 16);

    else if(add_uuid)
    {
        /*Check RSSI, flag and UUID type to ensure that advertising device is close and of right kind.*/
        if(p_ble_evt->evt.gap_evt.params.adv_report.rssi > -35 \
           && p_adv_report->data[2] == BLE_GAP_ADV_FLAG_BR_EDR_NOT_SUPPORTED \
           && p_adv_report->data[4] == BLE_GAP_AD_TYPE_128BIT_SERVICE_UUID_COMPLETE)
        {
              /*Check if UUID is already present in whitelist*/
              for(uint8_t i = 0; i < uuid_number; i++)
              {
                  if(memcmp(adv_uuid, whitelist[i], sizeof(adv_uuid)) == 0)
                  {
                      app_timer_stop(m_add_uuid_timer_id);
                      nrf_gpio_pin_set(LED_4);
                      nrf_gpio_pin_clear(LED_2);
                      existing_uuid = true;
                  }
              }
              if(!new_uuid_added && !existing_uuid)
              {
                  /*Copy the UUID from advertisement report to the next slot in whitelist*/
                  memcpy(&whitelist[uuid_number], &p_adv_report->data[5], 16);

                  app_timer_stop(m_add_uuid_timer_id);
                  nrf_gpio_pin_clear(LED_4);
                  new_uuid_added = true;

                  /*Write the added UUID to flash*/
                  NRF_LOG_INFO("Writing \"%x\" to flash.", whitelist[uuid_number]);
                  err_code = nrf_fstorage_write(&whitelist_storage, flash_addr, whitelist[uuid_number], sizeof(whitelist[uuid_number]), NULL);
                  APP_ERROR_CHECK(err_code);
                  NRF_LOG_INFO("Done.");

                  flash_addr += 0x10;
              }             
        }
    }
}break;