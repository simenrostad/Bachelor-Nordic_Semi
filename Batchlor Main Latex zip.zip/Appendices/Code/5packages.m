void SWI1_IRQHandler(bool radio_evt)
{
    uint32_t err_code;
    if (radio_evt)
    {
        counter += 1;

        if(counter == 2)
        {
            err_code = sd_ble_gap_adv_stop();
            APP_ERROR_CHECK(err_code);
        }
    }
}

/**@brief Function for initialising Radio Notification Software Interrupts.
 We will use this to limit the number of advertisement events and get a more realistic test
 while testing with the development kits*/
uint32_t radio_notification_init(uint32_t irq_priority, 
uint8_t notification_type, uint8_t notification_distance)
{
    uint32_t err_code;

    err_code = sd_nvic_ClearPendingIRQ(SWI1_IRQn);
    if (err_code != NRF_SUCCESS)
    {
        return err_code;
    }

    err_code = sd_nvic_SetPriority(SWI1_IRQn, irq_priority);
    if (err_code != NRF_SUCCESS)
    {
        return err_code;
    }

    err_code = sd_nvic_EnableIRQ(SWI1_IRQn);
    if (err_code != NRF_SUCCESS)
    {
        return err_code;
    }
    /* Configure the event*/
    return sd_radio_notification_cfg_set(notification_type, notification_distance);
}

int main(void)
{
    /* Initialize.*/
    log_init();
    ble_stack_init();
    
    /*Initializing Radio Notification Software Interrupts.*/
    uint32_t err_code;
    err_code = radio_notification_init(5, NRF_RADIO_NOTIFICATION_TYPE_INT_ON_INACTIVE, 
    NRF_RADIO_NOTIFICATION_DISTANCE_NONE);
    APP_ERROR_CHECK(err_code);

    advertising_init();

    NRF_LOG_INFO("Starting EHSB project");
    
    /**< Sleep between advertising intervals */
    for (;; )
    {
        if (NRF_LOG_PROCESS() == false)
        {
            power_manage();
        }
    }
}