/*NRF FSTORAGE instance*/
NRF_FSTORAGE_DEF(nrf_fstorage_t whitelist_storage) =
{
    /* Set a handler for fstorage events. */
    .evt_handler = fstorage_evt_handler,
    .start_addr = 0x3e000,
    .end_addr   = 0x3ffff,
};  

int main(void)
{
    ret_code_t rc;
    
    /*Initiate the fstorage instance*/
    rc = nrf_fstorage_init(&whitelist_storage, &nrf_fstorage_sd, NULL);
    APP_ERROR_CHECK(rc);
}