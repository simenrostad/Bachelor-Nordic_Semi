/*Initialize radio notification*/ 
static void radio_notification_init(void)
{
    ret_code_t err_code;
    uint32_t   softdevice_evt_irq_priority;
    
    err_code = sd_nvic_GetPriority(SD_EVT_IRQn, &softdevice_evt_irq_priority);
    APP_ERROR_CHECK(err_code);

    /*Make sure to use same IRQ priority as SD events to simplify state information handling*/
    err_code = sd_nvic_SetPriority(RADIO_NOTIFICATION_IRQn, softdevice_evt_irq_priority);
    APP_ERROR_CHECK(err_code);

    err_code = sd_nvic_EnableIRQ(RADIO_NOTIFICATION_IRQn);
    APP_ERROR_CHECK(err_code);

    err_code = sd_radio_notification_cfg_set(NRF_RADIO_NOTIFICATION_TYPE_INT_ON_INACTIVE, NRF_RADIO_NOTIFICATION_DISTANCE_NONE);
    APP_ERROR_CHECK(err_code);
}
void RADIO_NOTIFICATION_IRQHandler(void)
{
    if (m_start_scanning)
    {
        m_start_scanning = false;
        nrf_delay_us(2000);
        scan_start();
        NRF_LOG_INFO("Start scan after radio event");
    }
}