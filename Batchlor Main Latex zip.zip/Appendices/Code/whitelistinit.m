/* Two-dimensional array to hold the UUIDs that should be "whitelisted" */
uint8_t whitelist[30][16] = {0};





