/*Function for reading UUIDs from flash and putting them in whitelist on start-up*/
static void read_flash(void)
{
    ret_code_t err_code;
    /*Read flash at the address where uuid_number is stored*/
    err_code = nrf_fstorage_read(&whitelist_storage, 0x3e000, &uuid_number, 4);
    APP_ERROR_CHECK(err_code);

    /*If nothing has previously been written to flash, uuid_number will equal 255*/
    if(uuid_number == 255)
    {
        uuid_number = 0;
    }
    else
    {
        /*Read out as many UUIDs as indicated by uuid_number*/
        for(uint8_t i = 0; i < uuid_number; i++)
        {
            nrf_fstorage_read(&whitelist_storage, flash_addr, &whitelist[i], 16);
            flash_addr += 0x10;
        }
    } 
}