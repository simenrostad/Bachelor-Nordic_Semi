/* Function for handling button actions*/
void button_handler(uint8_t pin_no, uint8_t button_action)
{
   ret_code_t err_code;

   /*Button 2 is for adding a new UUID to the system.
   A push of the button sets add_uuid = true
   and release sets add_uuid = false, meaning that the button 
   needs to be held down in order to add a new UUID*/
   if(pin_no == BUTTON_2 && button_action == APP_BUTTON_PUSH)
   {
       if(uuid_number > 30)
       {
          NRF_LOG_INFO("\"Whitelist\" full");
          nrf_gpio_pin_clear(LED_2);
          nrf_gpio_pin_clear(LED_4);
          existing_uuid = true;
       }
       else
       {
          /*Timer to toggle LED_4 every 500ms*/
          app_timer_start(m_add_uuid_timer_id, APP_TIMER_TICKS(500), add_uuid_timeout_handler);
          add_uuid = true;
       }
   }
   if(pin_no == BUTTON_2 && button_action == APP_BUTTON_RELEASE)
   {
      /*Stop the toggling of LED_4*/
      app_timer_stop(m_add_uuid_timer_id);
      nrf_gpio_pin_set(LED_4);
      /*If a UUID has been added flash needs to be updated*/
      if(new_uuid_added)
      {
          uuid_number += 1;
          new_uuid_added = false;

          /*Erase old uuid_number from flash and write the new one*/
          err_code = nrf_fstorage_erase(&whitelist_storage, 0x3e000, 1, NULL);
          APP_ERROR_CHECK(err_code);

          NRF_LOG_INFO("Writing \"%x\" to flash.", uuid_number);
          err_code = nrf_fstorage_write(&whitelist_storage, 0x3e000, &uuid_number, 4, NULL);
          APP_ERROR_CHECK(err_code);
      }

      else if(existing_uuid)
      {
          nrf_gpio_pin_set(LED_2);
          existing_uuid = false;
      }

      add_uuid = false;
   }
   /*Holding button 3 erases "whitelist" after 4 seconds of toggling all LEDs*/
   if(pin_no == BUTTON_3 && button_action == APP_BUTTON_PUSH)
   {
        erasing_whitelist = true;
        scan_stop();
        nrf_gpio_pin_set(LED_2);
        nrf_gpio_pin_set(LED_3);
        nrf_gpio_pin_set(LED_4);
        /*Timer to toggle all the LEDs and show that flash is about to be erased*/
        app_timer_start(m_erase_whitelist_timer_id, APP_TIMER_TICKS(250), erase_uuids_timeout_handler);
   }
   if(pin_no == BUTTON_3 && button_action == APP_BUTTON_RELEASE)
   {  
        /*If the button is released to early - abort deletion*/
        if(!whitelist_erased)
        {
            app_timer_stop(m_erase_whitelist_timer_id);
            if(connected)
            {
                nrf_gpio_pin_clear(LED_3);
            }
        }
        nrf_gpio_pin_set(LED_2);
        nrf_gpio_pin_set(LED_4);
        if(!connected)
        {
            nrf_gpio_pin_set(LED_3);
        }
        scan_start();
        erasing_whitelist = false;
        delete_counter = 0;
   }
}