/*GAP defines*/

/**< BR/EDR not supported. */
#define BLE_GAP_ADV_FLAG_BR_EDR_NOT_SUPPORTED        0x04
/**< Complete list of 128 bit service UUIDs. */
#define BLE_GAP_AD_TYPE_128BIT_SERVICE_UUID_COMPLETE  0x07