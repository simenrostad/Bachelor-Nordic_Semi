/*Check for eligible UUID*/
if(p_adv_report->data[2] == BLE_GAP_ADV_FLAG_BR_EDR_NOT_SUPPORTED \
   && p_adv_report->data[4] == BLE_GAP_AD_TYPE_128BIT_SERVICE_UUID_COMPLETE)
{
     for(int8_t i = 0; i < button_number; i++)
     {  
        /*Compare received UUID to the entries in whitelist*/
        if(memcmp(adv_uuid, whitelist[i], sizeof(adv_uuid)) == 0)
        {
            nrf_gpio_pin_set(STOP_SIGN);
            nrf_gpio_pin_clear(LED_2);
            reset = true;
        }
     }
}